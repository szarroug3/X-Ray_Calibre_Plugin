# exceptions.py
'''Class of custom exceptions'''

class PageDoesNotExist(Exception):
    '''Exception for when page does not exist'''
    pass
