# X-Ray Calibre Plugin

Websites:
-------------------------------------------------------------------------------------------------------------------------------
Github Page: https://github.com/szarroug3/X-Ray_Calibre_Plugin

Mobileread Page: http://www.mobileread.com/forums/showthread.php?p=3301947#post3301947

This plugin will allow you to:
-------------------------------------------------------------------------------------------------------------------------------
	1. Create x-ray files for selected books
	2. Send previously generated x-ray files to device

	Note: Creating an x-ray file using this plugin will automatically update ASIN in book
	Note: Highlighting words should work but I have not tested with a book that has DRM so I don't know if it will work for them.

Preferences:
-------------------------------------------------------------------------------------------------------------------------------
	1. Use spoilers when creating x-ray
		- Will create file with shelfari spoilers enabled
	2. Send x-ray to device if connected
		- After creating x-ray file, file will automatically be sent to device
	3. Create x-ray for files that don't already have them when sending to device
		- When sending previously generated x-ray files, x-ray files will be generated for selected books that don't already have a file created

Testing:
-------------------------------------------------------------------------------------------------------------------------------
	This plugin has been tested using a Kindle PW2 on Windows 8 and 10.
